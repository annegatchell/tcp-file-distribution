#include <stdlib.h>

int stringcmp(char* input, char* comparison, int compLength);